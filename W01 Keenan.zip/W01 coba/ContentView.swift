//
//  ContentView.swift
//  W01 coba
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var emoji = "😩 😂 😊"
    @State private var isImageFlipped = false
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.7)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            VStack {
                Image("myPhoto")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 200, height: 200)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white, lineWidth: 6))
                    .shadow(radius: 10)


                Text("Hi! I'm Keenan")
                    .font(.system(size: 32, weight: .bold))
                    .foregroundColor(.white)
                    .padding()
                
                Text("I’m 20 years old")
                    .font(.title2)
                    .foregroundColor(.primary)
                    .padding()
                    .padding(.horizontal, 40)
                
                // Emoji dengan animasi perubahan
                Text("😃😘☺️")
                    .font(.system(size: 64))
                    .padding(.top, 20)
                    .shadow(radius: 5)
                    .padding()
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
