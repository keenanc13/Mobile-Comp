import SwiftUI

struct ContentView: View {
    @State private var checkedFruits: Set<String> = []
    let fruits = ["Kerja Tugas MobComp", "AFL Data Mining", "Beli Buah", "Vaksin Covid", "Selesai Projek Video"]
    
    var progress: Double {
        guard !fruits.isEmpty else { return 0 }
        return Double(checkedFruits.count) / Double(fruits.count)
    }
    

    var point: Int {
        Int(progress * 100)
    }
    
    var body: some View {
        VStack {
            Text("To Do List")
                .font(.largeTitle)
                .padding()

            progressCard(score: point)
                .padding()
            
            List(fruits, id: \.self) { fruit in
                HStack {
                    Image(systemName: checkedFruits.contains(fruit) ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(checkedFruits.contains(fruit) ? .green : .gray)
                        .onTapGesture {
                            if checkedFruits.contains(fruit) {
                                checkedFruits.remove(fruit)
                            } else {
                                checkedFruits.insert(fruit)
                            }
                        }
                    Text(fruit)
                    Spacer()
                }
                .padding()
            }
            
            HStack(spacing: 20) {
                Button(action: {
                    checkedFruits.removeAll()
                }) {
                    Text("Reset")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                
                Button(action: {
                    checkedFruits = Set(fruits)
                }) {
                    Text("Checklist All")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .padding(.top)
        }
        .padding()
    }
    
    @ViewBuilder
    func progressCard(score: Int) -> some View {
        VStack(spacing: 8) {
            Text("Current Progress")
                .font(.headline)
            ProgressView(value: Double(score), total: 100)
                .tint(Color.primary)
            Text("\(score)/100")
                .foregroundStyle(.secondary)
        }
        .padding()
        .background((score < 100) ? Color.white : Color.green)
        .cornerRadius(12)
        .shadow(radius: 4)
    }
}

#Preview {
    ContentView()
}
