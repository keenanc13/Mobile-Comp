//
//  TH_W02_KeenanApp.swift
//  TH_W02_Keenan
//
//  Created by student on 23/09/25.
//

import SwiftUI

@main
struct TH_W02_KeenanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
