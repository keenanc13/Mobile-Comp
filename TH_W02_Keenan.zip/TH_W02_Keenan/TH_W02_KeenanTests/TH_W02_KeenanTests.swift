//
//  TH_W02_KeenanTests.swift
//  TH_W02_KeenanTests
//
//  Created by student on 23/09/25.
//

import Testing
@testable import TH_W02_Keenan

struct TH_W02_KeenanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
