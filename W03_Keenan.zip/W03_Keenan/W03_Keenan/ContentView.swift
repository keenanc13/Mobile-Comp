import SwiftUI

struct ContentView: View {
    @State private var selectedTab = 0
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("🏡 Home Screen")
                    .font(.largeTitle)
                NavigationLink("Go to Details") {
                    DetailScreen()
                }
                NavigationLink("Show Item") {
                    ItemScreen()
                }
            }
            .navigationTitle("Home")
        }
    }
}

struct ItemScreen : View {
    let items = ["Tomato", "Potato", "Onion", "Carrot", "Cucumber"]
    
    var body : some View {
        List(items, id: \.self) { item in
            NavigationLink(destination: ItemDetailScreen(item: item)) {
                Text(item)
            }
        }
        .navigationTitle("Items")
        
    }
}

struct DetailScreen : View {
    var body : some View {
        VStack{
            Text("🏟️ Detail Screen")
                .font(.largeTitle)
            Text("You come from Home Screen")
        }
        .navigationTitle("Detail")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ItemDetailScreen : View {
    let item : String
    
    var body : some View {
        NavigationStack{
            VStack {
                Text("Welcome to Item Detail!")
                    .font(.title)
                Text("You Selected : \(item)")
            }
            .navigationTitle(item)
            .navigationBarTitleDisplayMode(.inline)
        }
        
    }
}

#Preview {
    ContentView()
}
