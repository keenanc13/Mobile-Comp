//
//  W03_KeenanApp.swift
//  W03_Keenan
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_KeenanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
