//
//  W03_KeenanTests.swift
//  W03_KeenanTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import W03_Keenan

struct W03_KeenanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
