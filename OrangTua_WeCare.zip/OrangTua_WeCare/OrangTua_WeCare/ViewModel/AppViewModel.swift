import Foundation
import SwiftUI

// MARK: - ViewModel

class AppViewModel: ObservableObject {
    
    // Data Kesehatan Vital
    @Published var heartRate: Int = 78
    @Published var systolicPressure: Int = 125
    @Published var diastolicPressure: Int = 80
    
    // Data Tasks/Reminder Harian
    @Published var tasks: [TaskItem] = [
        TaskItem(time: "07:00", title: "Minum Obat Pagi", isCompleted: false),
        TaskItem(time: "09:00", title: "Jalan Pagi 10 Menit", isCompleted: false),
        TaskItem(time: "13:00", title: "Minum Obat Siang", isCompleted: false),
        TaskItem(time: "19:00", title: "Minum Obat Malam", isCompleted: false)
    ]
    
    // Computed property: Persentase Task
    var taskCompletionPercentage: Int {
        let completedCount = tasks.filter { $0.isCompleted }.count
        let totalCount = tasks.count
        return totalCount > 0 ? (completedCount * 100) / totalCount : 0
    }
    
    // Computed property: Status Tekanan Darah
    var bloodPressureStatus: (String, Color) {
        let systolic = systolicPressure
        let diastolic = diastolicPressure
        
        // Batasan sederhana: Optimal/Normal < 130/85
        if systolic < 130 && diastolic < 85 {
            return ("Sehat ✅", Color(hex: "#a6d17d"))
        } else if systolic >= 140 || diastolic >= 90 {
            return ("PERINGATAN! 🛑", Color(hex: "#fa6255"))
        } else {
            return ("Perhatian ⚠️", Color(hex: "#fdcb46"))
        }
    }
    
    // Fungsi: Update Data Kesehatan (Simulasi)
    func updateHealthData() {
        heartRate = Int.random(in: 70...90)
        systolicPressure = [125, 135, 118, 142].randomElement()!
        diastolicPressure = [80, 88, 75, 95].randomElement()!
    }
    
    // Fungsi: Toggle Task
    func toggleTaskCompletion(for taskID: UUID) {
        if let index = tasks.firstIndex(where: { $0.id == taskID }) {
            tasks[index].isCompleted.toggle()
        }
    }
}
