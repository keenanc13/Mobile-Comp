import Foundation
import SwiftUI

// MARK: - Memory Game Model & Logic

struct MemoryCard: Identifiable {
    let id = UUID()
    let content: String // Emoji atau gambar
    var isFaceUp: Bool = false // Apakah kartu terbuka
    var isMatched: Bool = false // Apakah kartu sudah berpasangan
    let identifier: Int // Identifier untuk menentukan pasangan
}

class MemoryGame: ObservableObject {
    @Published var cards: [MemoryCard] = []
    @Published var moves: Int = 0
    @Published var gameStatus: String = "Temukan semua pasangan!"
    @Published var isGameOver: Bool = false
    
    // Indeks dari kartu yang saat ini terbuka (FaceUp) dan belum berpasangan
    private var indexOfOneAndOnlyFaceUpCard: Int? {
        get { cards.indices.filter { cards[$0].isFaceUp && !cards[$0].isMatched }.oneAndOnly }
        set { cards.indices.forEach { cards[$0].isFaceUp = ($0 == newValue) } }
    }
    
    // MARK: - Inisialisasi
    
    init() {
        startNewGame()
    }
    
    func startNewGame() {
        let cardContents = ["🍏", "🍊", "🍇", "🍓", "🍍", "🍌", "🍎", "🥝"]
        let pairsNeeded = 6 // Menggunakan 6 pasang (12 kartu) agar tidak terlalu rumit
        
        var newCards: [MemoryCard] = []
        
        for identifier in 0..<pairsNeeded {
            let content = cardContents[identifier]
            newCards.append(MemoryCard(content: content, identifier: identifier))
            newCards.append(MemoryCard(content: content, identifier: identifier))
        }
        
        cards = newCards.shuffled() // Acak kartu
        moves = 0
        isGameOver = false
        gameStatus = "Temukan semua pasangan!"
    }
    
    // MARK: - Logika Klik Kartu
    
    func choose(_ card: MemoryCard) {
        if let chosenIndex = cards.firstIndex(where: { $0.id == card.id }),
           !cards[chosenIndex].isFaceUp,
           !cards[chosenIndex].isMatched {
            
            // Logika Game
            if let potentialMatchIndex = indexOfOneAndOnlyFaceUpCard {
                // KARTU KEDUA DIKLIK
                moves += 1
                
                if cards[chosenIndex].identifier == cards[potentialMatchIndex].identifier {
                    // Berhasil Cocok!
                    cards[chosenIndex].isMatched = true
                    cards[potentialMatchIndex].isMatched = true
                    cards[chosenIndex].isFaceUp = true
                    
                    checkForGameOver()
                } else {
                    // Gagal Cocok
                    cards[chosenIndex].isFaceUp = true
                    
                    // Setelah jeda singkat, tutup kedua kartu
                    // Ini adalah trik penting di Memory Game!
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                        self.cards[chosenIndex].isFaceUp = false
                        self.cards[potentialMatchIndex].isFaceUp = false
                        self.indexOfOneAndOnlyFaceUpCard = nil // Bersihkan kartu yang terbuka
                    }
                }
            } else {
                // KARTU PERTAMA DIKLIK
                indexOfOneAndOnlyFaceUpCard = chosenIndex
                moves += 1
            }
        }
    }
    
    // MARK: - Cek Kemenangan
    
    private func checkForGameOver() {
        if cards.allSatisfy({ $0.isMatched }) {
            gameStatus = "🥳 SEMPURNA! Anda Menang dalam \(moves) langkah!"
            isGameOver = true
        }
    }
}

// MARK: - Utility Extension

extension Array {
    var oneAndOnly: Element? {
        if count == 1 {
            return first
        } else {
            return nil
        }
    }
}
