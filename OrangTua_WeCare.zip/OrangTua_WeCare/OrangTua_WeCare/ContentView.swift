import SwiftUI

struct ContentView: View {
    // ViewModel adalah sumber kebenaran tunggal untuk semua View
    @StateObject var viewModel = AppViewModel()
    
    var body: some View {
        TabView {
            // Tab 1: Dashboard
            DashboardView(viewModel: viewModel)
                .tabItem {
                    Label("Beranda", systemImage: "house.fill")
                }
            
            // Tab 2: Reminder
            ReminderView(viewModel: viewModel)
                .tabItem {
                    Label("Pengingat", systemImage: "bell.badge.fill")
                }
            
            // Tab 3: Health
            HealthView(viewModel: viewModel)
                .tabItem {
                    Label("Kesehatan Vital", systemImage: "heart.text.square.fill")
                }
            
            // Tab 4: Games
            GamesView()
                .tabItem {
                    Label("Permainan", systemImage: "gamecontroller.fill")
                }
        }
        .accentColor(Color(hex: "#387b38"))
    }
}

// MARK: - Preview (untuk Xcode)

#Preview {
    ContentView()
}
