import SwiftUI

// MARK: - Memory Game View (Akses dari GamesView)

struct MemoryGameView: View {
    @StateObject var game = MemoryGame()
    @Environment(\.dismiss) var dismiss
    
    // Pengaturan grid 4 kolom (12 kartu = 3 baris x 4 kolom)
    let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 4)
    
    var body: some View {
        VStack(spacing: 20) {
            
            // MARK: - Header & Tombol Kembali
            HStack {
                Text("Cek Daya Ingat")
                    .font(.largeTitle.bold())
                    .foregroundColor(Color(hex: "#387b38"))
                Spacer()
                Button("Kembali") {
                    dismiss()
                }
                .font(.title3.bold())
                .foregroundColor(.black)
                .padding(8)
                .background(Color(hex: "#fdcb46"))
                .cornerRadius(10)
            }
            .padding([.horizontal, .top])
            
            // MARK: - Info Status
            HStack {
                Text("Langkah: **\(game.moves)**")
                    .font(.title2)
                Spacer()
                Text(game.gameStatus)
                    .font(.title3)
            }
            .padding(.horizontal)
            
            // MARK: - Game Grid
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(game.cards) { card in
                    CardView(card: card)
                        .onTapGesture {
                            game.choose(card)
                        }
                        // Opacity saat kartu sudah berpasangan
                        .opacity(card.isMatched ? 0 : 1)
                        .aspectRatio(1, contentMode: .fit)
                }
            }
            .padding(.horizontal)
            
            Spacer()
            
            // MARK: - Tombol Mulai Baru
            Button("Mulai Permainan Baru") {
                game.startNewGame()
            }
            .font(.title2.bold())
            .padding(15)
            .frame(maxWidth: .infinity)
            .background(Color(hex: "#fa6255"))
            .foregroundColor(.white)
            .cornerRadius(15)
            .padding(.horizontal)
        }
        .padding(.top, 20)
        .background(Color(.systemGray6).ignoresSafeArea())
    }
}

// MARK: - Component: CardView

struct CardView: View {
    let card: MemoryCard
    
    var body: some View {
        ZStack {
            let shape = RoundedRectangle(cornerRadius: 15)
            
            if card.isFaceUp || card.isMatched {
                // Tampilan saat kartu terbuka
                shape.fill().foregroundColor(.white)
                shape.strokeBorder(Color(hex: "#387b38"), lineWidth: 4)
                Text(card.content)
                    .font(.system(size: 45)) // Emoji besar
            } else {
                // Tampilan saat kartu tertutup (Back)
                shape.fill(Color(hex: "#387b38")) // Warna Hijau gelap
            }
        }
    }
}
