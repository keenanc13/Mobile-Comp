import SwiftUI

// MARK: - TAB 4: Games View (Permainan)

struct GamesView: View {
    
    // Data rekomendasi games santai (di View karena ini data statis)
    let recommendedGames = [
        GameRecommendation(
            title: "Solitaire Klasik",
            description: "Permainan kartu strategi dan kesabaran, baik untuk fokus.",
            icon: "suit.club.fill",
            color: Color(hex: "#a6d17d")
        ),
        GameRecommendation(
            title: "Teka-teki Silang Harian",
            description: "Melatih kosakata dan memori jangka panjang.",
            icon: "square.grid.3x3.fill",
            color: Color(hex: "#fdcb46")
        ),
        GameRecommendation(
            title: "Mencocokkan Gambar (Memory)",
            description: "Melatih daya ingat dan konsentrasi visual.",
            icon: "rectangle.stack.fill",
            color: Color(hex: "#91bef8")
        ),
        GameRecommendation(
            title: "Sudoku Santai",
            description: "Logika sederhana dan menyenangkan untuk mengisi waktu luang.",
            icon: "number.square.fill",
            color: Color(hex: "#fa6255")
        )
    ]
    
    // State untuk memunculkan Sudoku
    @State private var isShowingSudoku = false
    
    @State private var isShowingMemory = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    Text("🎮 Permainan")
                        .font(.largeTitle.bold())
                        .foregroundColor(Color(hex: "#387b38"))
                        .padding([.horizontal, .top])
                    
                    Text("Pilih permainan untuk mengisi waktu luang dan menjaga ketajaman mental.")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding(.horizontal)
                    
                    // Daftar Rekomendasi Games
                    VStack(spacing: 15) {
                        ForEach(recommendedGames) { game in
                            
                            // Logika: Jika ini adalah Sudoku, buatlah menjadi Button yang memicu sheet
                            if game.title == "Sudoku Santai" {
                                Button(action: {
                                    isShowingSudoku = true // Aksi utama: tampilkan SudokuView
                                }) {
                                    GameCard(game: game) // Tampilan Kartu
                                }
                                .buttonStyle(PlainButtonStyle()) // Penting agar tombol terlihat seperti kartu normal
                            } else if game.title == "Mencocokkan Gambar (Memory)" {
                                                            Button(action: {
                                                                isShowingMemory = true // Tampilkan Memory Game View
                                                            }) {
                                                                GameCard(game: game)
                                                            }
                                                            .buttonStyle(PlainButtonStyle())
                            } else {
                                // Game Lainnya (Simulasi, hanya menampilkan kartu tanpa aksi)
                                GameCard(game: game)
                            }
                        }
                    }
                    .padding(.horizontal)
                    
                    Text("✨ Catatan: Sentuh kartu Sudoku untuk memulai permainan.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                        .padding(.top, 10)
                    
                }
                .padding(.vertical, 20)
            }
            .navigationTitle("Permainan")
            .navigationBarTitleDisplayMode(.inline)
            .background(Color(.systemGray6).ignoresSafeArea())
        }
        // MODIFIKASI: Menambahkan sheet untuk SudokuView
        .sheet(isPresented: $isShowingSudoku) {
            SudokuView()
        }
        // Sheet untuk Memory Game
                .sheet(isPresented: $isShowingMemory) {
                    MemoryGameView()
                }
    }
}

// MARK: - Komponen Khusus Games (Tambahkan komponen ini jika Anda tidak menyimpannya di file terpisah)

// Pastikan model GameRecommendation ada di file Models.swift Anda.
/*
struct GameRecommendation: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let icon: String
    let color: Color
}
*/

struct GameCard: View {
    let game: GameRecommendation
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: game.icon)
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
                .foregroundColor(.white)
                .padding(15)
                .background(game.color)
                .cornerRadius(10)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(game.title)
                    .font(.headline)
                    .foregroundColor(.black)
                Text(game.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(2)
            }
            
            Spacer()
            
            Image(systemName: "arrow.right.circle.fill")
                .foregroundColor(game.color)
                .font(.title)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}
