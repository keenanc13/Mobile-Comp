import SwiftUI

// MARK: - Sudoku View (Akses dari GamesView)

struct SudokuView: View {
    @StateObject var game = SudokuGame()
    @Environment(\.dismiss) var dismiss
    
    var selectedCell: (row: Int, col: Int)? {
        if let cell = game.board.flatMap({ $0 }).first(where: { $0.isSelected }) {
            let row = game.board.firstIndex(where: { $0.contains(where: { $0.id == cell.id }) })!
            let col = game.board[row].firstIndex(where: { $0.id == cell.id })!
            return (row, col)
        }
        return nil
    }
    
    var body: some View {
        VStack(spacing: 20) {
            
            // MARK: - Header & Tombol Kembali
            HStack {
                Text("Permainan Sudoku")
                    .font(.largeTitle.bold())
                    .foregroundColor(Color(hex: "#387b38"))
                Spacer()
                Button("Kembali") {
                    dismiss()
                }
                .font(.title3.bold())
                .foregroundColor(.black)
                .padding(8)
                .background(Color(hex: "#fdcb46"))
                .cornerRadius(10)
            }
            .padding([.horizontal, .top])
            
            // MARK: - Status Game
            Text(game.gameStatus)
                .font(.title3.bold())
                .foregroundColor(game.gameStatus.contains("Selamat") ? Color(hex: "#387b38") : Color(hex: "#fa6255"))
                .padding(.horizontal)
            
            // MARK: - Sudoku Grid
            VStack(spacing: 1) {
                ForEach(0..<9, id: \.self) { row in
                    HStack(spacing: 1) {
                        ForEach(0..<9, id: \.self) { col in
                            CellView(cell: game.board[row][col],
                                     row: row,
                                     col: col,
                                     game: game,
                                     selectedCell: selectedCell)
                                .padding(.trailing, (col + 1) % 3 == 0 && col != 8 ? 2 : 0)
                                .padding(.bottom, (row + 1) % 3 == 0 && row != 8 ? 2 : 0)
                        }
                    }
                }
            }
            .background(Color.black)
            .padding(.horizontal)
            
            Spacer()

            // MARK: - Input Angka
            NumberPad(game: game)
                .padding(.bottom, 10)
            
            // MARK: - Tombol Aksi
            Button("Mulai Permainan Baru") {
                game.restartGame()
            }
            .font(.title2.bold())
            .padding(15)
            .frame(maxWidth: .infinity)
            .background(Color(hex: "#fa6255"))
            .foregroundColor(.white)
            .cornerRadius(15)
            .padding(.horizontal)
            
        }
        .padding(.top, 20)
        .background(Color(.systemGray6).ignoresSafeArea())
    }
}

// MARK: - Components Revisi

struct CellView: View {
    let cell: SudokuCell
    let row: Int
    let col: Int
    @ObservedObject var game: SudokuGame
    let selectedCell: (row: Int, col: Int)?
    
    var isHighlighted: Bool {
        guard let selected = selectedCell else { return false }
        
        // Cek sel yang sama, baris, dan kolom
        if row == selected.row || col == selected.col { return true }
        
        // Cek kotak 3x3 yang sama
        let selectedBox = (selected.row / 3, selected.col / 3)
        let currentBox = (row / 3, col / 3)
        return selectedBox == currentBox
    }
    
    var body: some View {
        Text(cell.value != nil ? "\(cell.value!)" : "")
            .font(.title.bold())
            .frame(width: 40, height: 40)
            .background(backgroundColor)
            .foregroundColor(foregroundColor)
            .border(Color.black.opacity(0.1), width: 0.5)
            .contentShape(Rectangle())
            .onTapGesture {
                // >>> PERUBAHAN DI SINI <<<
                // Menghilangkan pengecekan 'if cell.isEditable'.
                // Semua sel (editable atau pre-filled) kini dapat diklik untuk menyeleksi dan highlight.
                game.selectCell(row: row, col: col)
            }
    }
    
    var foregroundColor: Color {
        if cell.isEditable {
            return cell.isError ? Color(hex: "#fa6255") : .blue
        } else {
            return .black // Nilai awal: Hitam
        }
    }
    
    var backgroundColor: Color {
        if cell.isSelected {
            return Color(hex: "#959595").opacity(0.9) // Sel yang dipilih: Kuning pekat
        } else if cell.initialValue != nil {
            return Color(.systemGray5) // Nilai awal: Abu-abu muda
        } else if isHighlighted {
            return Color(hex: "#d0d0d0")
        } else {
            return .white // Sel kosong: Putih
        }
    }
}

// ... (NumberPad, NumberButton, dan ClearButton tetap sama)

struct NumberPad: View {
    @ObservedObject var game: SudokuGame
    
    var body: some View {
        VStack(spacing: 15) {
            HStack(spacing: 15) {
                ForEach(1...5, id: \.self) { number in
                    NumberButton(number: number, game: game)
                }
            }
            HStack(spacing: 15) {
                ForEach(6...9, id: \.self) { number in
                    NumberButton(number: number, game: game)
                }
                ClearButton(game: game)
            }
        }
        .padding(.horizontal)
    }
}

struct NumberButton: View {
    let number: Int
    @ObservedObject var game: SudokuGame
    
    var body: some View {
        Button(action: {
            game.enterValue(value: number)
        }) {
            Text("\(number)")
                .font(.title2.bold())
                .frame(width: 55, height: 55)
                .background(Color(hex: "#387b38"))
                .foregroundColor(.white)
                .cornerRadius(12)
        }
        // Tombol input tetap dinonaktifkan jika sel yang dipilih TIDAK dapat diedit.
        .disabled(game.board.flatMap { $0 }.first(where: { $0.isSelected && $0.isEditable }) == nil)
    }
}

struct ClearButton: View {
    @ObservedObject var game: SudokuGame
    
    var body: some View {
        Button(action: {
            game.enterValue(value: nil)
        }) {
            Image(systemName: "xmark.circle.fill")
                .font(.title2.bold())
                .frame(width: 55, height: 55)
                .background(Color(.systemGray3))
                .foregroundColor(.white)
                .cornerRadius(12)
        }
        // Tombol input tetap dinonaktifkan jika sel yang dipilih TIDAK dapat diedit.
        .disabled(game.board.flatMap { $0 }.first(where: { $0.isSelected && $0.isEditable }) == nil)
    }
}

#Preview {
    SudokuView()
}
