import SwiftUI

// MARK: - TAB 2: Reminder View (Detail Tugas)

struct ReminderView: View {
    @ObservedObject var viewModel: AppViewModel
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    
                    Text("⏰ Daftar Tugas Harian")
                        .font(.largeTitle.bold())
                        .foregroundColor(Color(hex: "#387b38"))
                        .padding(.horizontal)
                    
                    TaskProgressCard(percentage: viewModel.taskCompletionPercentage)
                        .padding(.horizontal)
                    
                    // Daftar Reminder
                    ForEach($viewModel.tasks) { $task in
                        ReminderItem(task: $task, viewModel: viewModel)
                    }
                }
                .padding(.vertical, 20)
            }
            .navigationTitle("Pengingat")
            .navigationBarTitleDisplayMode(.inline)
            .background(Color(.systemGray6).ignoresSafeArea())
        }
    }
}

// MARK: - Komponen Khusus Reminder

struct TaskProgressCard: View {
    var percentage: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading) {
                    Text("Progres Penyelesaian Tugas")
                        .font(.headline)
                        .foregroundColor(.gray)
                    Text("\(percentage)%")
                        .font(.largeTitle.bold())
                        .foregroundColor(Color(hex: "#387b38"))
                }
                Spacer()
                ZStack {
                    Circle()
                        .stroke(Color(hex: "#a6d17d").opacity(0.3), lineWidth: 8)
                        .frame(width: 70, height: 70)
                    Circle()
                        .trim(from: 0, to: CGFloat(percentage) / 100.0)
                        .stroke(Color(hex: "#a6d17d"), style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .frame(width: 70, height: 70)
                        .rotationEffect(.degrees(-90))
                    Image(systemName: "list.bullet.clipboard.fill")
                        .foregroundColor(Color(hex: "#387b38"))
                        .font(.title2)
                }
            }
            
            if percentage < 100 {
                Text("🔔 Segera selesaikan tugas yang belum tercatat!")
                    .font(.subheadline)
                    .foregroundColor(Color(hex: "#fa6255"))
            } else {
                Text("Luar biasa! Semua tugas harian telah diselesaikan. 👍")
                    .font(.subheadline)
                    .foregroundColor(Color(hex: "#387b38"))
            }
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct ReminderItem: View {
    @Binding var task: TaskItem
    @ObservedObject var viewModel: AppViewModel
    
    var body: some View {
        HStack {
            Text(task.time)
                .font(.title3.bold())
                .foregroundColor(Color(hex: "#387b38"))
                .frame(width: 80, alignment: .leading)
            
            Text(task.title)
                .foregroundColor(.black)
                .font(.title3)
                .strikethrough(task.isCompleted, color: .gray)
            
            Spacer()
            
            Button(action: {
                viewModel.toggleTaskCompletion(for: task.id)
            }) {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .font(.title2)
                    .foregroundColor(task.isCompleted ? Color(hex: "#a6d17d") : .gray)
            }
        }
        .padding(15)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 3, x: 0, y: 2)
        .padding(.horizontal)
    }
}
