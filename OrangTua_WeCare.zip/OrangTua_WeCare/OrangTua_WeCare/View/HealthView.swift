import SwiftUI

// MARK: - TAB 3: Health View (Vitals)

struct HealthView: View {
    @ObservedObject var viewModel: AppViewModel
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 30) { // Spacing lebih besar
                    
                    Text("❤️ Pemeriksaan Kesehatan Vital")
                        .font(.largeTitle.bold())
                        .foregroundColor(Color(hex: "#387b38"))
                        .padding(.horizontal)
                    
                    // MARK: - DATA SAAT INI (Header dan Vitals Card)
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Data Saat Ini")
                            .font(.title2.bold())
                            .foregroundColor(.gray)
                            .padding(.leading)
                        
                        HStack(spacing: 16) {
                            // Detak Jantung
                            DashboardCard(title: "Detak Jantung",
                                          value: "\(viewModel.heartRate) bpm",
                                          color: "#fa6255",
                                          icon: "heart.fill") // Tambah ikon
                            
                            // Tekanan Darah
                            BloodPressureCard(
                                systolic: viewModel.systolicPressure,
                                diastolic: viewModel.diastolicPressure,
                                status: viewModel.bloodPressureStatus.0,
                                statusColor: viewModel.bloodPressureStatus.1
                            )
                        }
                        .padding(.horizontal)
                    }
                    
                    // MARK: - RIWAYAT KESEHATAN (Grafik Sederhana)
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Tren 7 Hari Terakhir (Simulasi)")
                            .font(.title2.bold())
                            .foregroundColor(.gray)
                            .padding(.leading)
                        
                        HealthHistoryCard()
                            .padding(.horizontal)
                    }

                    // MARK: - CALL TO ACTION
                    Button(action: {
                        viewModel.updateHealthData()
                    }) {
                        Text("Perbarui Data Kesehatan Terbaru")
                            .fontWeight(.bold)
                            .padding(20) // Padding lebih besar
                            .frame(maxWidth: .infinity)
                            .background(Color(hex: "#fdcb46"))
                            .foregroundColor(.black)
                            .cornerRadius(15) // Corner radius lebih besar
                    }
                    .padding(.horizontal)
                    
                }
                .padding(.vertical, 20)
            }
            .navigationTitle("Kesehatan Vital")
            .navigationBarTitleDisplayMode(.inline)
            .background(Color(.systemGray6).ignoresSafeArea())
        }
    }
}

// MARK: - Komponen Khusus Health

struct DashboardCard: View {
    var title: String
    var value: String
    var color: String
    var icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.white)
                    .font(.title2)
                Text(title)
                    .font(.headline)
                    .foregroundColor(.white)
            }
            Spacer()
            Text(value)
                .font(.largeTitle.bold()) // Lebih besar
                .foregroundColor(.white)
        }
        .padding(20)
        .frame(minWidth: 0, maxWidth: .infinity, idealHeight: 150, alignment: .leading) // Tinggi ditambah
        .background(Color(hex: color))
        .cornerRadius(15)
        .shadow(radius: 3)
    }
}

struct BloodPressureCard: View {
    var systolic: Int
    var diastolic: Int
    var status: String
    var statusColor: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "hand.raised.square.fill")
                    .foregroundColor(.white)
                    .font(.title2)
                Text("Tekanan Darah")
                    .font(.headline)
                    .foregroundColor(.white)
            }
            Spacer()
            Text("\(systolic)/\(diastolic)")
                .font(.largeTitle.bold()) // Lebih besar
                .foregroundColor(.white)
            
            Text(status)
                .font(.headline.bold()) // Lebih besar
                .foregroundColor(.black)
                .padding(8)
                .frame(maxWidth: .infinity)
                .background(statusColor.opacity(0.3)) // Background status menggunakan warna yang sama dengan opacity
                .cornerRadius(10)
            
        }
        .padding(20)
        .frame(minWidth: 0, maxWidth: .infinity, idealHeight: 150, alignment: .leading)
        .background(Color(hex: "#387b38"))
        .cornerRadius(15)
        .shadow(radius: 3)
    }
}

// MARK: - Komponen Baru: Health History Card (Simulasi Grafik)

struct HealthHistoryCard: View {
    
    // Data dummy untuk simulasi riwayat (misalnya, tekanan sistolik rata-rata harian)
    let historyData: [Int] = [130, 125, 128, 140, 135, 122, 128]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Detak Jantung & Tekanan Darah")
                .font(.headline)
                .foregroundColor(.black)
            
            // Area Grafik Sederhana (Simulasi Line Chart)
            HStack(alignment: .bottom, spacing: 10) {
                ForEach(historyData.indices, id: \.self) { index in
                    let dataPoint = historyData[index]
                    let normalizedHeight = CGFloat(dataPoint - 110) * 4 // Normalisasi untuk visual (range 110-140)
                    
                    VStack {
                        Spacer()
                        
                        // Bar Representasi
                        Rectangle()
                            .fill(dataPoint > 135 ? Color(hex: "#fa6255") : Color(hex: "#a6d17d"))
                            .frame(width: 20, height: normalizedHeight)
                            .cornerRadius(4)
                        
                        // Label Hari
                        Text("\(7 - historyData.count + 1 + index) Hari Lalu")
                            .font(.caption2)
                            .foregroundColor(.gray)
                    }
                    .frame(height: 100)
                }
            }
            .frame(maxWidth: .infinity)
            
            Divider()
            
            HStack {
                Image(systemName: "chart.line.uptrend.by.yoh.square.fill")
                    .foregroundColor(Color(hex: "#387b38"))
                Text("Grafik menunjukkan riwayat 7 hari.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

// Catatan: Pastikan Anda juga menyalin ulang komponen `DashboardCard` dan `BloodPressureCard` yang telah direvisi ini ke dalam file `Views/HealthView.swift` Anda, menggantikan versi lama yang ada di sana.
