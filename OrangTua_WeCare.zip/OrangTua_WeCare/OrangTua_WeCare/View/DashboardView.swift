import SwiftUI

// MARK: - TAB 1: Dashboard View (Ringkasan)

struct DashboardView: View {
    @ObservedObject var viewModel: AppViewModel
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    
                    // Header Sederhana
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 45, height: 45)
                            .foregroundColor(Color(hex: "#387b38"))
                        VStack(alignment: .leading) {
                            Text("Selamat pagi!")
                                .font(.headline)
                                .foregroundColor(.gray)
                            Text("Ibu/Bapak")
                                .font(.title2.bold())
                        }
                        Spacer()
                        Image(systemName: "gearshape.fill")
                            .foregroundColor(.black)
                            .padding(10)
                            .background(Color.white)
                            .clipShape(Circle())
                    }
                    .padding(.horizontal)
                    
                    // Ringkasan Status Kesehatan
                    DashboardSummaryCard(
                        percentage: viewModel.taskCompletionPercentage,
                        bpStatus: viewModel.bloodPressureStatus.0,
                        bpColor: viewModel.bloodPressureStatus.1
                    )
                    .padding(.horizontal)

                    // Daily Intake Card
                    DailyIntakeCard()
                        .padding(.horizontal)
                    
                }
                .padding(.vertical, 20)
            }
            .navigationBarHidden(true)
            .background(Color(.systemGray6).ignoresSafeArea())
        }
    }
}

// MARK: - Komponen Khusus Dashboard

struct DashboardSummaryCard: View {
    var percentage: Int
    var bpStatus: String
    var bpColor: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Ringkasan Kesehatan Harian")
                .font(.headline)
                .foregroundColor(.gray)

            HStack {
                Image(systemName: "heart.fill")
                    .foregroundColor(bpColor)
                Text("Tekanan Darah: \(bpStatus)")
                    .font(.title2.bold())
                    .foregroundColor(Color(hex: "#387b38"))
            }
            
            Divider()
            
            HStack {
                Text("Tugas Harian Selesai: \(percentage)%")
                    .font(.title3)
                Spacer()
                ZStack {
                    Circle()
                        .trim(from: 0, to: CGFloat(percentage) / 100.0)
                        .stroke(Color(hex: "#a6d17d"), style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .frame(width: 30, height: 30)
                        .rotationEffect(.degrees(-90))
                    Image(systemName: "list.bullet.clipboard")
                        .font(.caption)
                        .foregroundColor(Color(hex: "#387b38"))
                }
            }
            
            if percentage < 100 {
                Text("🔔 Ingatkan! Tugas belum 100%. Cek tab Pengingat.")
                    .font(.subheadline)
                    .foregroundColor(Color(hex: "#fa6255"))
            }
            
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct DailyIntakeCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("🍱 Ringkasan Nutrisi")
                .font(.title3.bold())
                .foregroundColor(.black)
            
            HStack {
                VStack(alignment: .leading) {
                    Text("Total Kalori Hari Ini")
                        .font(.headline)
                        .foregroundColor(.black)
                    Text("Diperkirakan: 1250 / 1920 Kcal")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                Spacer()
                Image(systemName: "fork.knife.circle.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(Color(hex: "#fdcb46"))
            }
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 3, x: 0, y: 2)
    }
}
