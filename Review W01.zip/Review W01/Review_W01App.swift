//
//  Review_W01App.swift
//  Review W01
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct Review_W01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
