//
//  ContentView.swift
//  Review W01
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    
    // Declare var
    //    @State private var isOn: Bool = false
    //    @State private var volume: Double = 0.5
    //    @State private var nama: String = ""
    //    @State private var point = 80
    //
    //    private func actionButton(_ title: String,
    //        action: @escaping () -> Void) -> some
    //        View {
    //        Button(title, action: action)
    //            .padding()
    //            .foregroundColor(.white)
    //            .background(Color.blue)
    //            .cornerRadius(10)
    //    }
    //
    //    private func progressCard(score: Int) ->
    //    some View{
    //        VStack(){
    //            Text("Current Score")
    //                .font(.headline)
    //            ProgressView(value: Double(score),total:100)
    //            Text("\(score)/\(100)")
    //                .foregroundStyle(.secondary)
    //        }
    //    }
    
    let fruits = ["Apple", "Banana", "Orange", "Mango","YES"]
    var body: some View {
        
        //EXERCISE 1
        //        ZStack {
        //            RoundedRectangle(cornerRadius: 20)
        //                .fill(.linearGradient(Gradient(colors: [.purple, .blue]), startPoint: .leading, endPoint: .trailing))
        //                .frame(width: 300, height: 200)
        //
        //            HStack {
        //                Text("Keenan")
        //                    .foregroundColor(.white)
        //                    .font(.largeTitle)
        //                    .padding()
        //
        //                VStack{
        //                    Text("🦧")
        //                    HStack{
        //                        Text("🍑")
        //                        Text("🍌")
        //                    }
        //
        //                }
        //
        //            }
        //
        //
        //
        //        }
        //        .padding()
        
        
        
        // Exercise 2
        
        //        ZStack {
        //            RoundedRectangle(cornerRadius: 20)
        //                .fill(.linearGradient(Gradient(colors: [.purple, .blue]), startPoint: .leading, endPoint: .trailing))
        //                .frame(width: 300, height: 200)
        //
        //            HStack {
        //                Text("Keenan")
        //                    .foregroundColor(.white)
        //                    .font(.largeTitle)
        //                    .padding(.bottom,140)
        //                    .padding(.trailing,100)
        //                VStack{
        //                    Text("🦧")
        //                    HStack{
        //                        Text("🍑")
        //                        Text("🍌")
        //                    }
        //
        //
        //                }
        //                .padding(.top,100)
        //            }
        //
        //
        //
        //        }
        //        .padding()
        
        
        
        
        // COBA Shadow
        
        //        VStack {
        //            Text("Hello, World! ")
        //                .padding()
        //                .background(Color.blue)
        //                .cornerRadius(10)
        //                .shadow(color: .red,radius: 10, x: 10, y: 10)
        //                .opacity(0.9)
        //                .font(.largeTitle)
        //                .frame(width: 300, height: 200)
        //                .border(Color.blue)
        //        }
        
        //        VStack {
        //            Button("Tekan Saya") {
        //                print( "Saya Dipencet")
        //            }
        //            .padding(.horizontal, 20)
        //            .padding(.vertical, 10)
        //            .background(.white)
        //            .overlay(RoundedRectangle(cornerRadius: 10).stroke(.purple,lineWidth: 3))
        //            .foregroundColor(.purple)
        //
        //        }
        
        // COntainer
        //        VStack {
        //            Toggle("Enable Notifications", isOn: $isOn)
        //                .padding()
        //            Text( isOn ? "Hore" : "Tidak")
        //                .padding()
        //
        //            Slider(value: $volume, in: 0...1)
        //            Text("Volume nowww: \(volume)%")
        //
        //            TextField("Masukkan Nama", text: $nama)
        //                .textFieldStyle(.roundedBorder)
        //                .padding()
        //            Text(nama == "" ? "Hai" :"WOI \(nama)")
        //        }
        //        .padding()
        
        //        VStack{
        //            progressCard(score: point)
        //            HStack{
        //                actionButton("Add 10") {
        //                    point += 10
        //                }
        //                actionButton("Reset") { point = 0}
        //            }
        //        }
        //        .padding()
        
        List(fruits, id: \.self) { fruit in
            HStack{
                Text(fruit)
                Spacer()
                Text("X Y Z A B")
            }
        }
    }
}
#Preview {
    ContentView()
}
