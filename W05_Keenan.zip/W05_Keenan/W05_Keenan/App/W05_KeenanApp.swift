//
//  W05_KeenanApp.swift
//  W05_Keenan
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_KeenanApp: App {
    var body: some Scene {
        WindowGroup {
            CounterHomeView()
        }
    }
}
