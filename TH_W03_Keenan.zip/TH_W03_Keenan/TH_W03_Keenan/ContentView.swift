import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            
            LocationView()
                .tabItem {
                    Image(systemName: "location.fill")
                    Text("Location")
                }
            
            ChartView()
                .tabItem {
                    Image(systemName: "chart.bar.fill")
                    Text("Chart")
                }
            
            SettingsView()
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("Settings")
                }
        }
    }
}

struct HomeView: View {
    @State private var searchText = ""
    
    var body: some View {
        ZStack {
            Color(hex: "E8E8E8")
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Main Content
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Header
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Good Morning,")
                                    .font(.title2)
                                Text("Mikaela")
                                    .font(.system(size: 42, weight: .bold))
                            }
                            
                            Spacer()
                            
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 60, height: 60)
                                .foregroundColor(.pink)
                        }
                        .padding(.horizontal, 24)
                        .padding(.top)
                        
                        // Search Bar
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)
                            TextField("Search", text: $searchText)
                                .foregroundColor(.primary)
                            
                            if !searchText.isEmpty {
                                Button(action: {
                                    searchText = ""
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.gray)
                                }
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .padding(.horizontal, 24)
                        
                        // Today's Goal Card
                        ZStack {
                            LinearGradient(
                                colors: [
                                    Color(hex: "5FC9D6"),
                                    Color(hex: "E5549F"),
                                    Color(hex: "F4436C")
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            .cornerRadius(24)
                            
                            VStack(spacing: 16) {
                                Text("Today's Goal")
                                    .font(.system(size: 32, weight: .bold))
                                    .foregroundColor(.white)
                                
                                HStack(spacing: 16) {
                                    // Running Goal
                                    VStack(spacing: 12) {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 20)
                                                .fill(Color.white.opacity(0.2))
                                                .frame(height: 160)
                                            VStack{
                                                Image(systemName: "figure.run")
                                                    .font(.system(size: 50))
                                                    .foregroundColor(.white)
                                                Text("4 Miles")
                                                    .font(.system(size: 24, weight: .bold))
                                                    .foregroundColor(.white)
                                                Text("@Thames Route")
                                                    .font(.system(size: 14))
                                                    .foregroundColor(.white.opacity(0.9))
                                            }
                                            .padding()
                                            
                                        }
                                    }
                                    
                                    // Kayaking Goal
                                    VStack(spacing: 12) {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 20)
                                                .fill(Color.white.opacity(0.2))
                                                .frame(height: 160)
                                            VStack{
                                                Image(systemName: "sailboat.fill")
                                                    .font(.system(size: 50))
                                                    .foregroundColor(.white)
                                                Text("2 Miles")
                                                    .font(.system(size: 24, weight: .bold))
                                                    .foregroundColor(.white)
                                                Text("@River Lea")
                                                    .font(.system(size: 14))
                                                    .foregroundColor(.white.opacity(0.9))
                                            }
                                            .padding()
                                            
                                        }
                                    }
                                }
                            }
                            .padding(24)
                        }
                        .frame(height: 290)
                        .padding(.horizontal, 24)
                        
                        // Stats Grid
                        HStack{
                            ZStack{
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.white)
                                    .frame(width: 170,height: 85)
                                HStack{
                                    Image(systemName:"waveform.path.ecg")
                                        .font(.title2)
                                        .foregroundColor(.purple)
                                        .padding(.bottom,40)
                                        .padding(.trailing,20)
                                    Text("68 Bpm")
                                        .padding(.top,40)
                                        .font(.title3)
                                }
                            }
                            .padding(.leading, 25)
                            
                            ZStack{
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.white)
                                    .frame(width: 170,height: 85)
                                HStack{
                                    Image(systemName:"flame.fill")
                                        .font(.title2)
                                        .foregroundColor(.orange)
                                        .padding(.bottom,40)
                                        .padding(.trailing,40)
                                    Text("O Kcal")
                                        .padding(.top,40)
                                        .font(.title3)
                                }
                            }
                            .padding(.leading, 10)
                        }
                        
                        
                        HStack{
                            ZStack{
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.white)
                                    .frame(width: 170,height: 85)
                                HStack{
                                    Image(systemName:"figure")
                                        .font(.title2)
                                        .foregroundColor(.teal)
                                        .padding(.bottom,40)
                                        .padding(.trailing,37)
                                    Text("73 Kg")
                                        .padding(.top,40)
                                        .font(.title3)
                                }
                            }
                            .padding(.leading, 25)
                            
                            ZStack{
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.white)
                                    .frame(width: 170,height: 85)
                                HStack{
                                    Image(systemName:"powersleep")
                                        .font(.title2)
                                        .foregroundColor(.blue)
                                        .padding(.bottom,40)
                                        .padding(.trailing,40)
                                    Text("O Kcal")
                                        .padding(.top,40)
                                        .font(.title3)
                                }
                            }
                            .padding(.leading, 10)
                        }
                    }
                }
                
                Spacer()
            }
        }
    }
}

struct LocationView: View {
    var body: some View {
        Text("Location View")
            .font(.largeTitle)
    }
}

struct ChartView: View {
    var body: some View {
        Text("Chart View")
            .font(.largeTitle)
    }
}

struct SettingsView: View {
    var body: some View {
        Text("Settings View")
            .font(.largeTitle)
    }
}

// Helper extension for hex colors
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

#Preview {
    ContentView()
}
