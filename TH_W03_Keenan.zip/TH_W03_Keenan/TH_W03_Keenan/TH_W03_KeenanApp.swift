//
//  TH_W03_KeenanApp.swift
//  TH_W03_Keenan
//
//  Created by student on 01/10/25.
//

import SwiftUI

@main
struct TH_W03_KeenanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
