//
//  TH_W03_KeenanTests.swift
//  TH_W03_KeenanTests
//
//  Created by student on 01/10/25.
//

import Testing
@testable import TH_W03_Keenan

struct TH_W03_KeenanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
