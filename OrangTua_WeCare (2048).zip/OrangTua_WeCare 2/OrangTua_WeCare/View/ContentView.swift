import SwiftUI

struct ContentView: View {
    // ViewModel is the single source of truth for all Views
    @StateObject var viewModel = AppViewModel()
    
    var body: some View {
        TabView {
            // Tab 1: Dashboard (includes tasks/reminders)
            DashboardView(viewModel: viewModel)
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            
            // Tab 2: Health
            HealthView(viewModel: viewModel)
                .tabItem {
                    Label("Vital Health", systemImage: "heart.text.square.fill")
                }
            
            // Tab 3: Games
            GamesView()
                .tabItem {
                    Label("Games", systemImage: "gamecontroller.fill")
                }
        }
        .accentColor(Color(hex: "#387b38"))
    }
}

// MARK: - Preview (for Xcode)

#Preview {
    ContentView()
}
