// File: ContentView.swift (Main Grid View)

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: MovieStore
    @State private var searchText: String = ""
    
    // NEW EASTER EGG STATE
    @State private var isMagicMode = false

    let columns = [
        GridItem(.adaptive(minimum: 170), spacing: 15)
    ]
    
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return store.movies
        } else {
            return store.movies.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    // MARK: - GRADIENT DINAMIS UNTUK EASTER EGG
    @State private var gradientStart = UnitPoint.topLeading
    @State private var gradientEnd = UnitPoint.bottomTrailing
    
    // Fungsi untuk mengubah posisi gradient secara acak
    func animateGradient() {
        Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { _ in // Ganti setiap 3 detik
            withAnimation(.easeInOut(duration: 3.0)) { // Animasi perubahan posisi
                gradientStart = UnitPoint(x: CGFloat.random(in: 0...1), y: CGFloat.random(in: 0...1))
                gradientEnd = UnitPoint(x: CGFloat.random(in: 0...1), y: CGFloat.random(in: 0...1))
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(filteredMovies) { movie in
                        NavigationLink(value: movie) {
                            MovieCardView(movie: movie)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.top, 10)
                .padding(.horizontal)
            }
            .navigationTitle("UCFlix")
            .navigationBarTitleDisplayMode(.large)
            // Warna Navigation Bar title akan berubah otomatis dengan preferredColorScheme
            
            .navigationDestination(for: Movie.self) { movie in
                MovieDetailView(movie: movie)
            }
            
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always))
            .onChange(of: searchText) { newText in
                if newText.lowercased() == "magic" {
                    withAnimation(.easeInOut(duration: 0.5)) {
                         isMagicMode = true
                    }
                    animateGradient() // Mulai animasi gradient
                } else if isMagicMode && newText.isEmpty {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        isMagicMode = false
                    }
                }
            }
            
            // MARK: - LATAR BELAKANG DENGAN GRADIENT ATAU WARNA SOLID
            .background(
                Group { // Group digunakan untuk switch antara Color dan LinearGradient
                    if isMagicMode {
                        LinearGradient(
                            colors: [
                                Color(red: 0.8, green: 0.1, blue: 0.8),   // Merah muda
                                Color(red: 0.1, green: 0.8, blue: 0.8),   // Cyan
                                Color(red: 0.8, green: 0.8, blue: 0.1)    // Kuning
                            ],
                            startPoint: gradientStart, // Posisi start dinamis
                            endPoint: gradientEnd      // Posisi end dinamis
                        )
                    } else {
                        Color.black.opacity(0.95) // Latar belakang gelap normal
                    }
                }
                .edgesIgnoringSafeArea(.all)
            )
            // MARK: - PENGATURAN TEMA WARNA UNTUK EASTER EGG
            // Mengubah skema warna Nav Bar agar teksnya tetap terlihat di atas gradient cerah
            .preferredColorScheme(isMagicMode ? .light : .dark)
            .animation(.easeInOut(duration: 0.5), value: isMagicMode) // Animasi transisi ke/dari magic mode
            
        }
        // Pastikan ScrollView memiliki latar belakang yang sama
        .background(Color.clear.edgesIgnoringSafeArea(.all)) // Transparan agar gradient di bawahnya terlihat
    }
}

#Preview {
    ContentView()
        .environmentObject(MovieStore())
}
