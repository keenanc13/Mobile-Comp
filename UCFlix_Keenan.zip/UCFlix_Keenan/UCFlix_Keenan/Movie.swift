// File: Movie.swift
// (DIUBAH: Menambahkan Model CastMember dan properti 'cast' ke Movie)

import Foundation
import SwiftUI

// Model untuk setiap Pemeran
struct CastMember: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let role: String // Nama Karakter
}

// MARK: - 1. MODEL
struct Movie: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let posterURL: String
    let genre: String
    let year: Int
    let runtime: String
    let director: String
    let description: String
    let cast: [CastMember] // <--- BARU: Daftar Pemeran
}

// MARK: - 2. DATA STORE
class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(
            title: "The Conjuring",
            posterURL: "https://image.tmdb.org/t/p/original/wVYREutTvI2tmxr6ujrHT704wGF.jpg",
            genre: "Horror", year: 2013, runtime: "128 min", director: "James Wan",
            description: "Berdasarkan kisah nyata, film ini menceritakan pasangan ahli paranormal Ed dan Lorraine Warren yang dipanggil untuk membantu sebuah keluarga yang diteror oleh kehadiran jahat di rumah pertanian terpencil mereka.",
            cast: [ // DATA PEMERAN BARU
                CastMember(name: "Vera Farmiga", role: "Lorraine Warren"),
                CastMember(name: "Patrick Wilson", role: "Ed Warren"),
                CastMember(name: "Lili Taylor", role: "Carolyn Perron")
            ]
        ),
        Movie(
            title: "Death On The Nile",
            posterURL: "https://image.tmdb.org/t/p/original/kVr5zIAFSPRQ57Y1zE7KzmhzdMQ.jpg",
            genre: "Mystery", year: 2023, runtime: "112 min", director: "Kenneth Branagh",
            description: "Detektif Belgia yang terkenal, Hercule Poirot, menemukan dirinya berada di atas kapal uap mewah di Sungai Nil. Perjalanan romantis berubah menjadi pencarian pembunuh ketika liburan bulan madu yang sempurna berakhir dengan tragedi.",
            cast: [
                CastMember(name: "Kenneth Branagh", role: "Hercule Poirot"),
                CastMember(name: "Gal Gadot", role: "Linnet Ridgeway Doyle"),
                CastMember(name: "Armie Hammer", role: "Simon Doyle")
            ]
        ),
        Movie(
            title: "Spider-Man",
            posterURL: "https://image.tmdb.org/t/p/original/gh4cZbhZxyTbgxQPxD0dOudNPTn.jpg",
            genre: "Action", year: 2002, runtime: "98 min", director: "Sam Raimi",
            description: "Setelah digigit laba-laba hasil modifikasi genetika, seorang siswa SMA bernama Peter Parker memperoleh kekuatan super. Ia harus belajar menggunakan kekuatan barunya untuk melawan penjahat Green Goblin yang jahat.",
            cast: [
                CastMember(name: "Tobey Maguire", role: "Peter Parker / Spider-Man"),
                CastMember(name: "Willem Dafoe", role: "Norman Osborn / Green Goblin"),
                CastMember(name: "Kirsten Dunst", role: "Mary Jane Watson")
            ]
        ),
        Movie(
            title: "The GodFather",
            posterURL: "https://image.tmdb.org/t/p/original/3Tf8vXykYhzHdT0BtsYTp570JGQ.jpg",
            genre: "Drama", year: 1972, runtime: "128 min", director: "Francis Ford Coppola",
            description: "Kisah epik keluarga kriminal Corleone. Ketika patriark Don Vito Corleone mencoba menyerahkan kendali kekaisarannya yang tersembunyi, putra bungsunya, Michael, dipaksa untuk terlibat dalam kehidupan kriminal.",
            cast: [
                CastMember(name: "Marlon Brando", role: "Vito Corleone"),
                CastMember(name: "Al Pacino", role: "Michael Corleone"),
                CastMember(name: "James Caan", role: "Sonny Corleone")
            ]
        ),
        Movie(
            title: "Terminator",
            posterURL: "https://image.tmdb.org/t/p/original/3hiZuNyxyWG3Rv8VCkMkAKXFtti.jpg",
            genre: "Sci-Fi", year: 1984, runtime: "92 min", director: "James Cameron",
            description: "Seorang pembunuh siber dikirim kembali dari masa depan untuk membunuh Sarah Connor, yang putranya di masa depan akan memimpin manusia melawan mesin. Seorang prajurit juga dikirim untuk melindunginya.",
            cast: [
                CastMember(name: "Arnold Schwarzenegger", role: "The Terminator"),
                CastMember(name: "Linda Hamilton", role: "Sarah Connor"),
                CastMember(name: "Michael Biehn", role: "Kyle Reese")
            ]
        ),
        Movie(
            title: "Red Notice",
            posterURL: "https://image.tmdb.org/t/p/original/lAXONuqg41NwUMuzMiFvicDET9Y.jpg",
            genre: "Comedy", year: 2021, runtime: "105 min", director: "Rawson Marshall Thurber",
            description: "Ketika seorang agen FBI papan atas dipaksa bekerja sama dengan pencuri seni paling terkenal di dunia, mereka harus menangkap penjahat licik yang sedang mencoba mencuri telur emas berharga milik Cleopatra.",
            cast: [
                CastMember(name: "Dwayne Johnson", role: "John Hartley"),
                CastMember(name: "Ryan Reynolds", role: "Nolan Booth"),
                CastMember(name: "Gal Gadot", role: "The Bishop")
            ]
        )
    ]
}

// ... (UCFlixApp struct tetap sama)
