// File: MovieDetailView.swift
// (DIUBAH: Menambahkan Programmatic Navigation ke CastInfoView)

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    let dummyRating = Int.random(in: 75...98)

    var body: some View {
        ZStack {
            Color.black.opacity(0.95).edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    // MARK: - SIMPLIFIED POSTER HEADER
                    AsyncImage(url: URL(string: movie.posterURL)) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .scaledToFit()
                        } else if phase.error != nil {
                            Text("Poster gagal dimuat. Cek koneksi.")
                                .foregroundColor(.red)
                                .frame(height: 500)
                        } else {
                            ProgressView()
                                .frame(height: 500)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 500)
                    .clipped()
                    .overlay(
                        LinearGradient(
                            colors: [Color.clear, Color.black.opacity(0.95)],
                            startPoint: .center,
                            endPoint: .bottom
                        )
                    )

                    // MARK: - DETAIL TEXT CONTENT
                    VStack(alignment: .leading, spacing: 10) {
                        
                        Text(movie.title)
                            .font(.system(size: 34, weight: .bold)).foregroundColor(.white)
                        
                        HStack {
                            Text("\(movie.year)").foregroundColor(.gray)
                            Text("• \(movie.runtime)").foregroundColor(.gray)
                            Text("Rating: \(dummyRating)%").foregroundColor(Color.green)
                        }.font(.subheadline)
                        
                        Text(movie.genre)
                            .font(.caption).padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color.red.opacity(0.7)).foregroundColor(.white).cornerRadius(4)
                        
                        Divider().background(Color.gray.opacity(0.5))
                        
                        HStack(spacing: 15) {
                            Button("▶️ PLAY MOVIE") {}.buttonStyle(.borderedProminent).tint(.red)
                            Button("Trailer") {}.buttonStyle(.bordered)
                        }.padding(.vertical, 5)
                        
                        Text("Sutradara: **\(movie.director)**").foregroundColor(.white)

                        Text(movie.description)
                            .font(.body).foregroundColor(.white.opacity(0.9)).padding(.top, 5)
                            .lineSpacing(5)
                        
                        // MARK: - PROGRAMMATIC NAVIGATION (+5 pts)
                        Divider().background(Color.gray.opacity(0.5)) // Garis sebelum Navigation Link
                        
                        NavigationLink(destination: CastInfoView(movie: movie)) {
                            HStack {
                                Text("Lihat Daftar Pemeran").foregroundColor(.white)
                                Spacer()
                                Image(systemName: "chevron.right").foregroundColor(.gray)
                            }
                        }
                        .padding(.vertical, 5) // Tombol navigasi ke CastInfoView
                        
                        Divider().background(Color.gray.opacity(0.5)) // Garis setelah Navigation Link
                        
                    }
                    .padding(.horizontal)
                    .padding(.top, -30)
                    .padding(.bottom, 50)
                }
            }
        }
        // Pengaturan Navigasi
        .navigationTitle("").navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text(movie.title)
                    .font(.headline)
                    .foregroundColor(.white)
            }
        }
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(Color.black.opacity(0.95), for: .navigationBar)
        .preferredColorScheme(.dark)
    }
}
