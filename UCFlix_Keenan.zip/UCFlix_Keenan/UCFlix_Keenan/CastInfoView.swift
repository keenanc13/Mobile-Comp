// File: CastInfoView.swift
// (NEW: Layar Detail Tambahan/Deeper Detail Screen)

import SwiftUI

struct CastInfoView: View {
    let movie: Movie // Menerima data Movie
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.95).edgesIgnoringSafeArea(.all)
            
            List {
                ForEach(movie.cast) { member in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(member.name)
                            .font(.headline)
                            .foregroundColor(.white)
                        Text("(\(member.role))")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .listRowBackground(Color.gray.opacity(0.1)) // Latar belakang baris
                }
            }
            .listStyle(.plain) // Gaya List yang bersih
            .background(Color.clear) // Transparan agar ZStack background terlihat
            
        }
        .navigationTitle("Pemeran - \(movie.title)")
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarBackground(Color.black.opacity(0.95), for: .navigationBar)
        .preferredColorScheme(.dark)
    }
}
