// File: MovieCardView.swift
// (FINAL: Fungsional dengan AsyncImage, siap untuk di-tap)

import SwiftUI

struct MovieCardView: View {
    let movie: Movie
    let cardWidth: CGFloat = 170

    var body: some View {
        // Menggunakan GeometryReader dan ZStack untuk layout yang fleksibel dan layering
        ZStack(alignment: .bottomLeading) {
            
            // 1. ASYNCIMAGE UNTUK POSTER
            AsyncImage(url: URL(string: movie.posterURL)) { phase in
                if let image = phase.image {
                    image
                        .resizable()
                        .scaledToFill()
                } else if phase.error != nil {
                    // State 2: Error
                    Color.red.opacity(0.3)
                        .overlay(Text("❌").font(.largeTitle).foregroundColor(.white))
                } else {
                    // State 3: Loading (Placeholder solid)
                    Color.gray.opacity(0.3)
                }
            }
            .frame(width: cardWidth, height: cardWidth * 1.5)
            .clipped() // Memastikan gambar terpotong sesuai batas frame
            
            // 2. Gradient Overlay untuk teks (dari .clear ke .black)
            LinearGradient(
                gradient: Gradient(colors: [.clear, .black.opacity(0.9)]),
                startPoint: .center,
                endPoint: .bottom
            )
            
            // 3. Detail Teks
            VStack(alignment: .leading) {
                Text(movie.title)
                    .font(.headline)
                    .fontWeight(.heavy)
                    .lineLimit(2)
                
                Text("\(movie.year) • \(movie.genre)")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .foregroundColor(.white)
            .padding(10)

        }
        .frame(width: cardWidth, height: cardWidth * 1.5)
        .cornerRadius(8)
        
        // Shadow yang dramatis
        .shadow(color: .black.opacity(0.7), radius: 10, x: 0, y: 5)
        
        // Border tipis
        .overlay(
            RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.1), lineWidth: 1)
        )
        // Catatan: Tidak ada gesture atau scaleEffect di sini agar NavigationLink di ContentView dapat berfungsi.
        // Animation press akan ditangani oleh .buttonStyle(.plain) di ContentView.
    }
}
