//
//  UCFlix_KeenanTests.swift
//  UCFlix_KeenanTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import UCFlix_Keenan

struct UCFlix_KeenanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
