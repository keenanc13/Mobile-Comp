//
//  W09_KeenanApp.swift
//  W09_Keenan
//
//  Created by student on 06/11/25.
//

import SwiftUI

@main
struct W09_KeenanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
